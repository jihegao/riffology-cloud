"""Deterministic first-come, first-served single-server queue model."""


def run(config):
    """Run the queue and return model snapshots."""
    parameters = config.get("parameters", {})
    customers = parameters.get("customers", config.get("customers", 5))
    service_time = parameters.get("service_time", config.get("service_time", 2))
    seed = config.get("seed", 0)

    snapshots = [{
        "schemaVersion": "riffology.visual/v0.1",
        "frame": 0,
        "time": 0,
        "space": {"type": "lane", "lanes": ["queue", "server-1"]},
        "agents": [],
        "metrics": {"completed": 0, "mean_wait": 0},
    }]
    previous_finish = 0
    total_wait = 0
    for index in range(customers):
        arrival = seed % 3 + 2 * index
        start = max(arrival, previous_finish)
        finish = start + service_time
        total_wait += start - arrival
        completed = index + 1
        snapshots.append({
            "schemaVersion": "riffology.visual/v0.1",
            "frame": completed,
            "time": finish,
            "space": {"type": "lane", "lanes": ["queue", "server-1"]},
            "agents": [],
            "metrics": {"completed": completed, "mean_wait": total_wait / completed},
        })
        previous_finish = finish
    return {"model": "fcfs_queue", "snapshots": snapshots}
