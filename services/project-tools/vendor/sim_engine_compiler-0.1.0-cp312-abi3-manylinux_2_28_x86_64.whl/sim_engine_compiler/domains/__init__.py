"""Domain packages supply explicit semantics to the generic compiler."""
