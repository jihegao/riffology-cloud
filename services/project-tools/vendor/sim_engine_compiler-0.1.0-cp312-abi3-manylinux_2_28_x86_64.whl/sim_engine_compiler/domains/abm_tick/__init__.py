"""Restricted tick-based agent model domain."""

from .lowering import compile_abm_tick

__all__ = ["compile_abm_tick"]
