"""Reserved for aircraft mission and support domain semantics."""
