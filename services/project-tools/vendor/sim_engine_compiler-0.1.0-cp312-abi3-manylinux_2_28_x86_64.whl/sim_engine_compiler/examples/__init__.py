"""Packaged, synthetic aircraft-support example for offline product acceptance."""
