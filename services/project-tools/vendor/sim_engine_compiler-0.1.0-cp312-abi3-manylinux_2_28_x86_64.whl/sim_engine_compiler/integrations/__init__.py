"""External system boundaries; the generic core remains integration-independent."""
