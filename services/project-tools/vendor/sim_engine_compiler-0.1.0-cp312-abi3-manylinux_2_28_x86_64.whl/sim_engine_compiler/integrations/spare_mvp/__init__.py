"""Reserved for canonical spare_mvp input and result integration."""
