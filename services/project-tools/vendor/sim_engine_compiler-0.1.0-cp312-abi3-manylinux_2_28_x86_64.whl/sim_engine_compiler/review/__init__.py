"""Offline, bounded design views of persisted validated aircraft IR."""

from .exporter import export_review

__all__ = ["export_review"]
