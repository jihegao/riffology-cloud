"""Read-only, evidence-limited queries of persisted simulation results."""

from .query import query_trace

__all__ = ["query_trace"]
